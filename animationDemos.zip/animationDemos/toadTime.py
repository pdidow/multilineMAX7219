import time
from random import randrange

# Import library
import multilineMAX7219 as LEDMatrix

# The following imported variables make it easier to feed parameters to the library functions
from multilineMAX7219 import DIR_L, DIR_R, DIR_U, DIR_D
from multilineMAX7219 import DIR_LU, DIR_RU, DIR_LD, DIR_RD
from multilineMAX7219 import GFX_ON, GFX_OFF

# Initialise the library and the MAX7219/8x8LED arrays
LEDMatrix.init()

try:
    while True:  # Infinite loop
        # Define frog image1 as a pixel map
        frog105 = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0],
            [0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0],
            [0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0],
            [0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        ]
        # Define frog image1 as a pixel map
        frog106 = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0],
            [0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0],
            [0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            [0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0],
            [0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        ]

        # Flip the frames vertically
        frog106 = list(reversed(frog106))
        frog105 = list(reversed(frog105))

        LEDMatrix.gfx_set_all(GFX_OFF)
        LEDMatrix.gfx_sprite_array(frog106, 7, 8)
        LEDMatrix.gfx_render()
        time.sleep(1)

        LEDMatrix.gfx_set_all(GFX_OFF)
        LEDMatrix.gfx_sprite_array(frog105, 7, 8)
        LEDMatrix.gfx_render()
        time.sleep(1)

        for repeat in range(2):
            for scroll in (DIR_L, DIR_LU, DIR_U, DIR_RU, DIR_R, DIR_RD, DIR_D, DIR_LD):
                moves = 2 * repeat + 1
                if scroll in [DIR_R, DIR_RD, DIR_D, DIR_LD]:
                    moves += 1
                for loop in range(moves):
                    LEDMatrix.gfx_scroll(scroll)
                    LEDMatrix.gfx_render()
                    time.sleep(0.1)
                    LEDMatrix.gfx_set_all(GFX_OFF)
                    LEDMatrix.gfx_sprite_array(frog106, 7, 8)
                    LEDMatrix.gfx_render()
                    time.sleep(0.25)

                    LEDMatrix.gfx_set_all(GFX_OFF)
                    LEDMatrix.gfx_sprite_array(frog105, 7, 8)
                    LEDMatrix.gfx_render()
                    time.sleep(0.25)

                    # Get the current time and format it
                    current_time = time.strftime("%H:%M:%S")
                    # LEDMatrix.scroll_message_horiz([current_time], 1, 8)
                    # LEDMatrix.clear_all()
                    # time.sleep(1)
                    # Print text characters using gfx_ method

                    for letter in range(len(current_time)):
                        LEDMatrix.gfx_letter(ord(current_time[letter]), (letter % LEDMatrix.MATRIX_WIDTH) * 8,
                                             ((LEDMatrix.MATRIX_HEIGHT - 1) - letter // LEDMatrix.MATRIX_WIDTH) * 8 - 1)
                        LEDMatrix.gfx_render()
                        time.sleep(0.2)

        for repeat in range(2):
            for scroll in (DIR_L, DIR_LU, DIR_U, DIR_RU, DIR_R, DIR_RD, DIR_D, DIR_LD):
                moves = 2 * repeat + 1
                if scroll in [DIR_R, DIR_RD, DIR_D, DIR_LD]:
                    moves += 1
                for loop in range(moves):
                    LEDMatrix.gfx_scroll(scroll)
                    LEDMatrix.gfx_render()
                    time.sleep(0.1)
        time.sleep(1)

except KeyboardInterrupt:
    # reset array
    LEDMatrix.scroll_message_horiz(["", "Goodbye!", ""], 1, 8)
    LEDMatrix.clear_all()
