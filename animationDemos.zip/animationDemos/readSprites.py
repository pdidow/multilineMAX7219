import os

def read_sprite_files(folder_name):
    sprites = []
    for filename in os.listdir(folder_name):
        if filename.startswith("sprite_") and filename.endswith(".txt"):
            file_path = os.path.join(folder_name, filename)
            with open(file_path, "r") as file:
                try:
                    # Read each line and remove square brackets and extra characters
                    content_str = file.read().replace('[', '').replace(']', '').replace(',', ' ')
                    # Split the string into rows and columns
                    rows = content_str.split('\n')
                    content = [[int(num) for num in row.split()] for row in rows if row]
                    sprites.append(content)
                except ValueError as e:
                    print(f"Error reading file {filename}: {e}")
    return sprites

if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("Usage: python3 spriteReader.py <folder_name>")
        sys.exit(1)

    folder_name = sys.argv[1]
    sprites = read_sprite_files(folder_name)

    # Display the loaded sprites
    for i, sprite in enumerate(sprites, start=1):
        print(f"Sprite {i}:\n{sprite}\n")
