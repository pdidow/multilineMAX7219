import time
import feedparser
import multilineMAX7219 as LEDMatrix

def display_rss_feed_vertically(rss_url, scroll_speed=0.1):
    LEDMatrix.init()

    try:
        while True:
            # Fetch the RSS feed
            feed = feedparser.parse(rss_url)

            # Display each title vertically
            for entry in feed.entries:
                LEDMatrix.scroll_message_vert([entry.title], 1, 8)
                time.sleep(scroll_speed)

    except KeyboardInterrupt:
        # Clear the display on exit
        LEDMatrix.clear_all()

if __name__ == "__main__":
    # Replace 'YOUR_RSS_FEED_URL' with the actual RSS feed URL you want to display
    rss_feed_url = 'http://www.cbc.ca/cmlink/rss-technology'
    display_rss_feed_vertically(rss_feed_url)
